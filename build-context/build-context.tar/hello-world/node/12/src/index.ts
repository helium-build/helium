
console.log("Hello World");

