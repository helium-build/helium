
sbt run
