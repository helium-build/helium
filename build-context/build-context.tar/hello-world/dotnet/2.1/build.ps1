
dotnet run
dotnet pack
dotnet nuget push bin\Debug\*.nupkg
