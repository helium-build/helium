
echo "Saving message artifact"

helium-artifact message.txt
